class CabreaichError(Exception):
    """Base exception for the cabreaich project."""
    pass

class APIError(CabreaichError):
    """Exception raised for errors interacting with external APIs."""
    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code

    def __str__(self):
        if self.status_code:
            return f"[Status {self.status_code}] {super().__str__()}"
        return super().__str__()

class ValidationError(CabreaichError):
    """Exception raised for data validation errors."""
    def __init__(self, message: str, details: dict | None = None):
        super().__init__(message)
        self.details = details

# Add other specific, shared exceptions as needed
